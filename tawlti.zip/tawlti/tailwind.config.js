/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}", "./lib/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        orange: {
          50: "#FFF5EB",
          100: "#FFE6CC",
          200: "#FFCB99",
          300: "#FFAD66",
          400: "#F58F3A",
          500: "#E8741E",
          600: "#C95D12",
          700: "#9F470E",
        },
        green: {
          50: "#EEF6F1",
          100: "#D5E8DB",
          200: "#A8CDB4",
          500: "#2F7A52",
          600: "#1F6140",
          700: "#174B32",
          800: "#0F3924",
          900: "#0A2918",
        },
        sand: "#FFF9F0",
      },
      fontFamily: {
        sans: ["Cairo", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 10px 30px -12px rgba(15, 57, 36, 0.25)",
      },
    },
  },
  plugins: [],
};
