-- =====================================================================
-- Tawlti - طاولتي : schéma SQL (PostgreSQL / Supabase)
-- جدولان منفصلان تمامًا: admins (الإدارة) و restaurant_owners (أصحاب المطاعم)
-- =====================================================================

-- ---------- 1) حالة الحساب ----------
do $$ begin
  create type restaurant_status as enum ('pending', 'approved', 'rejected');
exception when duplicate_object then null; end $$;

-- ---------- 2) جدول الإدارة (admins) ----------
-- لا يكتب فيه أي مستخدم من التطبيق؛ يُملأ يدويًا من لوحة Supabase فقط.
create table if not exists public.admins (
  id         uuid primary key references auth.users(id) on delete cascade,
  name       text not null,
  email      text not null unique,
  created_at timestamptz not null default now()
);

-- ---------- 3) جدول أصحاب المطاعم (restaurant_owners) ----------
create table if not exists public.restaurant_owners (
  id                   uuid primary key references auth.users(id) on delete cascade,
  name                 text not null,                 -- اسم الشخص
  restaurant_name      text not null,                 -- اسم المطعم
  restaurant_photo_url text,                          -- صورة المطعم (Storage)
  phone_whatsapp       text not null,                 -- الهاتف / واتساب
  email                text not null unique,
  status               restaurant_status not null default 'pending',
  created_at           timestamptz not null default now(),
  reviewed_by          uuid references public.admins(id),
  reviewed_at          timestamptz
);

create index if not exists restaurant_owners_status_idx
  on public.restaurant_owners (status, created_at desc);

-- ---------- 4) دالة التحقق من المدير ----------
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.admins a where a.id = auth.uid());
$$;

-- ---------- 5) تسجيل من راجع الطلب تلقائيًا ----------
create or replace function public.set_review_info()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.status is distinct from old.status then
    new.reviewed_by := auth.uid();
    new.reviewed_at := now();
  end if;
  return new;
end;
$$;

drop trigger if exists trg_set_review_info on public.restaurant_owners;
create trigger trg_set_review_info
  before update on public.restaurant_owners
  for each row execute function public.set_review_info();

-- ---------- 6) الأمان (Row Level Security) ----------
alter table public.admins            enable row level security;
alter table public.restaurant_owners enable row level security;

-- admins: المدير فقط يقرأ سجله؛ لا كتابة من العميل إطلاقًا
drop policy if exists "admins read self" on public.admins;
create policy "admins read self" on public.admins
  for select using (id = auth.uid());

-- restaurant_owners: التسجيل — صاحب المطعم ينشئ سجله هو فقط وبحالة pending
drop policy if exists "owner insert own pending" on public.restaurant_owners;
create policy "owner insert own pending" on public.restaurant_owners
  for insert to authenticated
  with check (id = auth.uid() and status = 'pending');

-- صاحب المطعم يقرأ سجله فقط
drop policy if exists "owner read own" on public.restaurant_owners;
create policy "owner read own" on public.restaurant_owners
  for select to authenticated
  using (id = auth.uid());

-- المدير يقرأ الجميع
drop policy if exists "admin read all" on public.restaurant_owners;
create policy "admin read all" on public.restaurant_owners
  for select to authenticated
  using (public.is_admin());

-- المدير وحده يغيّر الحالة (قبول / رفض)؛ لا توجد سياسة تحديث لصاحب المطعم
drop policy if exists "admin update status" on public.restaurant_owners;
create policy "admin update status" on public.restaurant_owners
  for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- المدير فقط يحذف
drop policy if exists "admin delete" on public.restaurant_owners;
create policy "admin delete" on public.restaurant_owners
  for delete to authenticated
  using (public.is_admin());

-- ---------- 7) صور المطاعم (Supabase Storage) ----------
insert into storage.buckets (id, name, public)
values ('restaurant-photos', 'restaurant-photos', true)
on conflict (id) do nothing;

-- صاحب المطعم يرفع داخل مجلده فقط (اسم المجلد = uid) وبصور فقط
drop policy if exists "owner upload own photo" on storage.objects;
create policy "owner upload own photo" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'restaurant-photos'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- يسمح باستبدال الصورة (upsert) داخل المجلد نفسه
drop policy if exists "owner update own photo" on storage.objects;
create policy "owner update own photo" on storage.objects
  for update to authenticated
  using (bucket_id = 'restaurant-photos' and (storage.foldername(name))[1] = auth.uid()::text);

-- ---------- 8) التحديث المباشر للوحة الإدارة (Realtime) ----------
do $$ begin
  alter publication supabase_realtime add table public.restaurant_owners;
exception when duplicate_object then null; end $$;

-- ---------- 9) إنشاء حساب المدير (مرة واحدة، يدويًا) ----------
-- 1. Authentication > Users > Add user (بريد + كلمة مرور قوية، فعّل Auto Confirm)
-- 2. انسخ الـ UUID الخاص به ونفّذ:
--
-- insert into public.admins (id, name, email)
-- values ('<UUID_DU_COMPTE_ADMIN>', '<الاسم>', '<البريد>');
--
-- ملاحظة: يجب تعطيل "Confirm email" من
-- Authentication > Providers > Email حتى يتمكن صاحب المطعم من رفع الصورة
-- وإنشاء ملفه فور التسجيل (الموافقة تتم من الإدارة بدلًا من تأكيد البريد).
