"use client";

import Link from "next/link";
import Shell from "@/components/Shell";
import Logo from "@/components/Logo";
import { useLang } from "@/lib/i18n";

export default function Home() {
  const { t } = useLang();
  return (
    <Shell>
      <div className="text-center pt-6 pb-8">
        <div className="flex justify-center mb-6">
          <Logo size={96} withText={false} />
        </div>
        <h1 className="text-4xl font-extrabold text-green-800">
          Tawlti <span className="text-orange-500">طاولتي</span>
        </h1>
        <p className="mt-3 text-green-700">{t("tagline")}</p>
      </div>

      <div className="space-y-3">
        <Link
          href="/register"
          className="block text-center rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-extrabold py-3.5 shadow-card"
        >
          {t("home_register")}
        </Link>
        <Link
          href="/login"
          className="block text-center rounded-xl bg-green-800 hover:bg-green-900 text-white font-extrabold py-3.5"
        >
          {t("home_login")}
        </Link>
      </div>
    </Shell>
  );
}
