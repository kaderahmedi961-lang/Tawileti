"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { useLang } from "@/lib/i18n";
import Shell, { Field, inputClass, primaryBtn } from "@/components/Shell";

export default function LoginPage() {
  const { t } = useLang();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState(null); // { fr, ar, tone }
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setNotice(null);
    if (!email.trim() || !password) return setError(t("err_required"));

    setLoading(true);
    try {
      const { data, error: signErr } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (signErr) throw signErr;

      const { data: owner, error: readErr } = await supabase
        .from("restaurant_owners")
        .select("status")
        .eq("id", data.user.id)
        .maybeSingle();
      if (readErr) throw readErr;

      if (!owner) {
        await supabase.auth.signOut();
        return setError(t("no_profile"));
      }

      const status = owner.status;

      if (status === "approved") {
        router.push("/dashboard");
        return;
      }

      // pending ou rejected : pas de session
      await supabase.auth.signOut();
      if (status === "pending") {
        setNotice({ main: t("pending_login_msg"), alt: t("pending_login_msg_ar"), tone: "orange" });
      } else {
        setNotice({ main: t("rejected_msg"), alt: t("rejected_msg_ar"), tone: "red" });
      }
    } catch (err) {
      console.error(err);
      const msg = String(err?.message || "").toLowerCase();
      if (err?.code === "invalid_credentials" || err?.code === "validation_failed" || msg.includes("invalid login")) {
        setError(t("err_credentials"));
      } else if (msg.includes("fetch") || msg.includes("network")) {
        setError(t("err_network"));
      } else {
        setError(t("err_generic"));
      }
    } finally {
      setLoading(false);
    }
  };

  const toneClass =
    notice?.tone === "red"
      ? "bg-red-50 border-red-200 text-red-700"
      : "bg-orange-50 border-orange-200 text-orange-700";

  return (
    <Shell>
      <div className="text-center mb-6">
        <h1 className="text-2xl font-extrabold text-green-800">
          {t("login_title")} <span className="text-orange-500">- {t("login_title_ar")}</span>
        </h1>
        <p className="text-sm text-green-700 mt-2">{t("login_sub")}</p>
      </div>

      <form onSubmit={onSubmit} className="bg-white rounded-3xl shadow-card p-5 space-y-4">
        <Field label={t("f_email")}>
          <input
            className={inputClass}
            type="email"
            dir="ltr"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
          />
        </Field>

        <Field label={t("f_password")}>
          <input
            className={inputClass}
            type="password"
            dir="ltr"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
          />
        </Field>

        {notice && (
          <div className={`rounded-xl border px-4 py-3 text-center font-bold ${toneClass}`}>
            <div>{notice.main}</div>
            <div className="text-sm opacity-80 mt-1">{notice.alt}</div>
          </div>
        )}

        {error && (
          <div className="rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm font-semibold px-4 py-3">
            {error}
          </div>
        )}

        <button type="submit" disabled={loading} className={primaryBtn}>
          {loading ? t("login_loading") : t("login_btn")}
        </button>
      </form>

      <p className="text-center text-sm text-green-700 mt-5">
        {t("no_account")}{" "}
        <Link href="/register" className="font-extrabold text-orange-600 underline">
          {t("home_register")}
        </Link>
      </p>
    </Shell>
  );
}
