"use client";

import { useState } from "react";
import Link from "next/link";
import { supabase } from "@/lib/supabase";
import { PHOTO_BUCKET } from "@/lib/supabaseConfig";
import { useLang } from "@/lib/i18n";
import Shell, { Field, inputClass, primaryBtn } from "@/components/Shell";

const MAX_SIZE = 5 * 1024 * 1024;

export default function RegisterPage() {
  const { t } = useLang();
  const [form, setForm] = useState({ name: "", restaurantName: "", phone: "", email: "", password: "" });
  const [photo, setPhoto] = useState(null);
  const [preview, setPreview] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const onPhoto = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) return setError(t("err_photo_type"));
    if (file.size > MAX_SIZE) return setError(t("err_photo_size"));
    setError("");
    setPhoto(file);
    setPreview(URL.createObjectURL(file));
  };

  const errorFor = (err) => {
    const code = err?.code || "";
    const msg = String(err?.message || "").toLowerCase();
    if (code === "user_already_exists" || code === "email_exists" || msg.includes("already registered")) return t("err_email_used");
    if (code === "email_address_invalid" || code === "validation_failed" || msg.includes("invalid email")) return t("err_email_invalid");
    if (code === "weak_password") return t("err_weak");
    if (code === "no_session") return t("err_confirm_email");
    if (msg.includes("fetch") || msg.includes("network")) return t("err_network");
    return t("err_generic");
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setError("");
    const { name, restaurantName, phone, email, password } = form;
    if (!name.trim() || !restaurantName.trim() || !phone.trim() || !email.trim() || !password) {
      return setError(t("err_required"));
    }
    if (!photo) return setError(t("err_photo"));

    setLoading(true);
    try {
      // 1) Compte Auth (e-mail + mot de passe)
      const { data, error: signErr } = await supabase.auth.signUp({ email: email.trim(), password });
      if (signErr) throw signErr;
      // Sans session (confirmation e-mail activée) on ne peut ni envoyer la photo ni créer le profil
      if (!data.session || !data.user) throw { code: "no_session" };
      const uid = data.user.id;

      // 2) Photo dans Storage (dossier = uid)
      const ext = (photo.name.split(".").pop() || "jpg").toLowerCase();
      const path = `${uid}/photo.${ext}`;
      const { error: upErr } = await supabase.storage
        .from(PHOTO_BUCKET)
        .upload(path, photo, { contentType: photo.type, upsert: true });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from(PHOTO_BUCKET).getPublicUrl(path);

      // 3) Profil dans restaurant_owners avec statut "pending"
      const { error: insErr } = await supabase.from("restaurant_owners").insert({
        id: uid,
        name: name.trim(),
        restaurant_name: restaurantName.trim(),
        restaurant_photo_url: pub.publicUrl,
        phone_whatsapp: phone.trim(),
        email: email.trim().toLowerCase(),
        status: "pending",
      });
      if (insErr) throw insErr;

      // On déconnecte : un compte "pending" ne doit pas rester connecté
      await supabase.auth.signOut();
      setDone(true);
    } catch (err) {
      console.error(err);
      setError(errorFor(err));
    } finally {
      setLoading(false);
    }
  };

  if (done) {
    return (
      <Shell>
        <div className="bg-white rounded-3xl shadow-card p-8 text-center mt-6">
          <div className="mx-auto w-16 h-16 rounded-full bg-orange-100 flex items-center justify-center text-3xl mb-4">
            ⏳
          </div>
          <p className="text-lg font-extrabold text-green-800">Votre compte est en attente d&apos;approbation par l&apos;administration.</p>
          <p className="text-lg font-extrabold text-orange-600 mt-2" dir="rtl">
            حسابك بانتظار موافقة الإدارة
          </p>
          <p className="text-sm text-green-700/70 mt-3">Your account is waiting for admin approval</p>
          <Link href="/login" className="inline-block mt-6 text-green-800 font-bold underline">
            {t("login_btn")}
          </Link>
        </div>
      </Shell>
    );
  }

  return (
    <Shell>
      <div className="text-center mb-6">
        <h1 className="text-2xl font-extrabold text-green-800">
          Join Tawlti <span className="text-orange-500">- انضم إلى طاولتي</span>
        </h1>
        <p className="text-sm text-green-700 mt-2">{t("register_sub")}</p>
      </div>

      <form onSubmit={onSubmit} className="bg-white rounded-3xl shadow-card p-5 space-y-4">
        <Field label={t("f_name")}>
          <input className={inputClass} value={form.name} onChange={set("name")} autoComplete="name" />
        </Field>

        <Field label={t("f_restaurant")}>
          <input className={inputClass} value={form.restaurantName} onChange={set("restaurantName")} />
        </Field>

        <Field label={t("f_photo")} hint={t("f_photo_hint")}>
          <div className="relative flex items-center justify-center h-36 rounded-xl border-2 border-dashed border-orange-300 bg-orange-50 overflow-hidden cursor-pointer">
            {preview ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={preview} alt="" className="absolute inset-0 w-full h-full object-cover" />
            ) : (
              <span className="text-4xl">📷</span>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={onPhoto}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
          </div>
        </Field>

        <Field label={t("f_phone")}>
          <input
            className={inputClass}
            type="tel"
            inputMode="tel"
            dir="ltr"
            placeholder="+222 ..."
            value={form.phone}
            onChange={set("phone")}
            autoComplete="tel"
          />
        </Field>

        <Field label={t("f_email")}>
          <input
            className={inputClass}
            type="email"
            dir="ltr"
            value={form.email}
            onChange={set("email")}
            autoComplete="email"
          />
        </Field>

        <Field label={t("f_password")} hint={t("f_password_hint")}>
          <input
            className={inputClass}
            type="password"
            dir="ltr"
            value={form.password}
            onChange={set("password")}
            autoComplete="new-password"
          />
        </Field>

        {error && (
          <div className="rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm font-semibold px-4 py-3">
            {error}
          </div>
        )}

        <button type="submit" disabled={loading} className={primaryBtn}>
          {loading ? t("register_loading") : t("register_btn")}
        </button>
      </form>

      <p className="text-center text-sm text-green-700 mt-5">
        {t("have_account")}{" "}
        <Link href="/login" className="font-extrabold text-orange-600 underline">
          {t("login_btn")}
        </Link>
      </p>
    </Shell>
  );
}
