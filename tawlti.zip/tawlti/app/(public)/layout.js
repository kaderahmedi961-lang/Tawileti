"use client";

import { LangProvider } from "@/lib/i18n";

// Pages publiques : accueil, inscription, connexion
export default function PublicLayout({ children }) {
  return <LangProvider>{children}</LangProvider>;
}
