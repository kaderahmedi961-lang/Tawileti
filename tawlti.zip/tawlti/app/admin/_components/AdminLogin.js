"use client";

import { useState } from "react";
import { useAdminLang } from "../_lib/i18n";
import { useAdminAuth } from "../_lib/auth";
import AdminHeader from "./AdminHeader";

const input =
  "w-full rounded-xl border border-green-100 bg-white px-4 py-3 text-base text-green-900 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-orange-400";

export default function AdminLogin({ denied }) {
  const { t } = useAdminLang();
  const { login, logout } = useAdminAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (!email.trim() || !password) return setError(t("err_required"));
    setLoading(true);
    try {
      await login(email.trim(), password);
    } catch (err) {
      setError(t("err_credentials"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-sand">
      <AdminHeader />
      <main className="mx-auto max-w-md px-4 py-8">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-extrabold text-green-800">
            {t("title")} <span className="text-orange-500">- {t("title_ar")}</span>
          </h1>
          <p className="text-sm text-green-700 mt-2">{t("login_sub")}</p>
        </div>

        {denied && (
          <div className="rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm font-semibold px-4 py-3 mb-4 text-center">
            {t("denied")}
            <button onClick={logout} className="block mx-auto mt-2 underline font-bold">
              {t("logout")}
            </button>
          </div>
        )}

        <form onSubmit={onSubmit} className="bg-white rounded-3xl shadow-card p-5 space-y-4">
          <label className="block">
            <span className="block text-sm font-bold text-green-800 mb-1">{t("email")}</span>
            <input className={input} type="email" dir="ltr" value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>
          <label className="block">
            <span className="block text-sm font-bold text-green-800 mb-1">{t("password")}</span>
            <input
              className={input}
              type="password"
              dir="ltr"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          {error && (
            <div className="rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm font-semibold px-4 py-3">
              {error}
            </div>
          )}
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-orange-500 hover:bg-orange-600 disabled:opacity-60 text-white font-extrabold py-3.5 shadow-card"
          >
            {loading ? t("logging") : t("login")}
          </button>
        </form>
      </main>
    </div>
  );
}
