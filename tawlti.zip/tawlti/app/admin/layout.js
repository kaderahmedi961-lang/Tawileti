"use client";

import { AdminLangProvider, useAdminLang } from "./_lib/i18n";
import { AdminAuthProvider, useAdminAuth } from "./_lib/auth";
import AdminHeader from "./_components/AdminHeader";
import AdminLogin from "./_components/AdminLogin";

function Gate({ children }) {
  const { t } = useAdminLang();
  const { status, logout } = useAdminAuth();

  if (status === "loading") {
    return (
      <div className="min-h-screen bg-sand flex items-center justify-center text-green-700 font-bold">
        {t("loading")}
      </div>
    );
  }

  // Pas connecté, ou connecté avec un compte qui n'est pas l'admin
  if (status !== "admin") return <AdminLogin denied={status === "denied"} />;

  return (
    <div className="min-h-screen bg-sand">
      <AdminHeader onLogout={logout} />
      <main className="mx-auto max-w-4xl px-4 py-6">{children}</main>
    </div>
  );
}

// Layout /admin : fournisseurs, auth et en-tête propres à l'administration
export default function AdminLayout({ children }) {
  return (
    <AdminLangProvider>
      <AdminAuthProvider>
        <Gate>{children}</Gate>
      </AdminAuthProvider>
    </AdminLangProvider>
  );
}
