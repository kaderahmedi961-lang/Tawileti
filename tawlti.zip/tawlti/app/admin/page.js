"use client";

import { useEffect, useState } from "react";
import { adminSb } from "./_lib/supabase";
import { useAdminLang } from "./_lib/i18n";

export default function AdminPage() {
  const { t } = useAdminLang();
  const [tab, setTab] = useState("pending");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState("");
  const [error, setError] = useState("");

  // Données 100 % réelles : table restaurant_owners filtrée par statut,
  // rechargée automatiquement à chaque changement (Supabase Realtime).
  useEffect(() => {
    let alive = true;

    const load = async () => {
      const { data, error: err } = await adminSb
        .from("restaurant_owners")
        .select("*")
        .eq("status", tab)
        .order("created_at", { ascending: false });
      if (!alive) return;
      if (err) {
        console.error(err);
        setError(t("err_generic"));
        setItems([]);
      } else {
        setError("");
        setItems(data || []);
      }
      setLoading(false);
    };

    setLoading(true);
    load();

    const channel = adminSb
      .channel(`owners-${tab}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "restaurant_owners" }, load)
      .subscribe();

    return () => {
      alive = false;
      adminSb.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const setStatus = async (id, status) => {
    setBusyId(id);
    setError("");
    const { error: err } = await adminSb.from("restaurant_owners").update({ status }).eq("id", id);
    if (err) {
      console.error(err);
      setError(t("err_generic"));
    } else {
      // Retrait immédiat de la liste courante (le realtime confirmera)
      setItems((prev) => prev.filter((r) => r.id !== id));
    }
    setBusyId("");
  };

  const tabs = [
    ["pending", t("tab_pending")],
    ["approved", t("tab_approved")],
    ["rejected", t("tab_rejected")],
  ];
  const emptyText = { pending: t("empty_pending"), approved: t("empty_approved"), rejected: t("empty_rejected") }[tab];

  return (
    <>
      <h1 className="text-xl font-extrabold text-green-800 mb-5">
        {t("title")} <span className="text-orange-500">· {t("title_ar")}</span>
      </h1>

      <div className="flex gap-2 mb-5 overflow-x-auto">
        {tabs.map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-extrabold transition ${
              tab === key ? "bg-green-800 text-white" : "bg-white text-green-800 border border-green-100"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {error && (
        <div className="rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm font-semibold px-4 py-3 mb-4">
          {error}
        </div>
      )}

      {loading ? (
        <p className="text-center text-green-700 mt-10">{t("loading")}</p>
      ) : items.length === 0 ? (
        <div className="bg-white rounded-3xl shadow-card p-10 text-center">
          <div className="text-4xl mb-3">🍽️</div>
          <p className="text-green-700 font-bold">{emptyText}</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {items.map((r) => (
            <div key={r.id} className="bg-white rounded-3xl shadow-card overflow-hidden">
              {r.restaurant_photo_url && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={r.restaurant_photo_url} alt="" className="w-full h-40 object-cover" />
              )}
              <div className="p-4">
                <h2 className="text-lg font-extrabold text-green-800">{r.restaurant_name}</h2>
                <p className="text-sm text-green-700 font-semibold">{r.name}</p>
                <div className="mt-3 space-y-1 text-sm" dir="ltr">
                  <a
                    href={`https://wa.me/${String(r.phone_whatsapp || "").replace(/[^\d]/g, "")}`}
                    target="_blank"
                    rel="noreferrer"
                    className="block text-orange-600 font-bold"
                  >
                    📱 {r.phone_whatsapp}
                  </a>
                  <div className="text-green-700/80 break-all">✉️ {r.email}</div>
                </div>

                <div className="flex gap-2 mt-4">
                  {tab !== "approved" && (
                    <button
                      disabled={busyId === r.id}
                      onClick={() => setStatus(r.id, "approved")}
                      className="flex-1 rounded-xl bg-green-700 hover:bg-green-800 disabled:opacity-60 text-white font-extrabold py-2.5"
                    >
                      ✓ {t("approve")}
                    </button>
                  )}
                  {tab !== "rejected" && (
                    <button
                      disabled={busyId === r.id}
                      onClick={() => setStatus(r.id, "rejected")}
                      className="flex-1 rounded-xl bg-white border border-red-300 text-red-600 hover:bg-red-50 disabled:opacity-60 font-extrabold py-2.5"
                    >
                      ✕ {t("reject")}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
