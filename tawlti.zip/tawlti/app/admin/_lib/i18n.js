"use client";

import { createContext, useContext, useEffect, useState } from "react";

const dict = {
  fr: {
    title: "Administration Tawlti",
    title_ar: "إدارة طاولتي",
    login_sub: "Accès réservé à l'administrateur.",
    email: "E-mail",
    password: "Mot de passe",
    login: "Se connecter",
    logging: "Connexion…",
    logout: "Déconnexion",
    loading: "Chargement…",
    denied: "Ce compte n'a pas accès à l'administration.",
    err_required: "Veuillez remplir tous les champs.",
    err_credentials: "E-mail ou mot de passe incorrect.",
    err_generic: "Une erreur est survenue. Réessayez.",
    tab_pending: "En attente",
    tab_approved: "Approuvés",
    tab_rejected: "Refusés",
    approve: "Approuver",
    reject: "Refuser",
    empty_pending: "Aucune demande en attente.",
    empty_approved: "Aucun restaurant approuvé pour le moment.",
    empty_rejected: "Aucun restaurant refusé.",
  },
  ar: {
    title: "إدارة طاولتي",
    title_ar: "Administration Tawlti",
    login_sub: "الدخول مخصص للمدير فقط.",
    email: "البريد الإلكتروني",
    password: "كلمة المرور",
    login: "دخول",
    logging: "جارٍ الدخول…",
    logout: "تسجيل الخروج",
    loading: "جارٍ التحميل…",
    denied: "هذا الحساب لا يملك صلاحية الإدارة.",
    err_required: "يرجى ملء جميع الحقول.",
    err_credentials: "البريد الإلكتروني أو كلمة المرور غير صحيحة.",
    err_generic: "حدث خطأ. حاول مرة أخرى.",
    tab_pending: "قيد الانتظار",
    tab_approved: "المقبولة",
    tab_rejected: "المرفوضة",
    approve: "قبول",
    reject: "رفض",
    empty_pending: "لا توجد طلبات قيد الانتظار.",
    empty_approved: "لا توجد مطاعم مقبولة حاليًا.",
    empty_rejected: "لا توجد مطاعم مرفوضة.",
  },
};

const Ctx = createContext({ lang: "fr", setLang: () => {}, t: (k) => k });

export function AdminLangProvider({ children }) {
  const [lang, setLangState] = useState("fr");

  useEffect(() => {
    try {
      const s = localStorage.getItem("tawlti_lang");
      if (s === "fr" || s === "ar") setLangState(s);
    } catch (e) {}
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);

  const setLang = (l) => {
    setLangState(l);
    try {
      localStorage.setItem("tawlti_lang", l);
    } catch (e) {}
  };

  const t = (k) => dict[lang][k] ?? dict.fr[k] ?? k;
  return <Ctx.Provider value={{ lang, setLang, t }}>{children}</Ctx.Provider>;
}

export const useAdminLang = () => useContext(Ctx);
