import { createClient } from "@supabase/supabase-js";
import { SUPABASE_URL, SUPABASE_ANON_KEY } from "@/lib/supabaseConfig";

// Client administrateur : clé de session propre, indépendante des restaurateurs.
export const adminSb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { storageKey: "tawlti-admin-auth" },
});
