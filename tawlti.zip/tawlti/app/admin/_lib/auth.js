"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { adminSb } from "./supabase";

const Ctx = createContext(null);

// Auth admin : l'utilisateur doit exister dans la table `admins` (lecture de sa propre ligne,
// protégée par RLS). Un restaurateur connecté ici est refusé : "denied".
// status : "loading" | "anon" | "denied" | "admin"
export function AdminAuthProvider({ children }) {
  const [state, setState] = useState({ status: "loading", user: null });

  useEffect(() => {
    let alive = true;

    const check = async (session) => {
      if (!alive) return;
      const user = session?.user ?? null;
      if (!user) return setState({ status: "anon", user: null });
      const { data, error } = await adminSb.from("admins").select("id").eq("id", user.id).maybeSingle();
      if (!alive) return;
      setState({ status: !error && data ? "admin" : "denied", user });
    };

    adminSb.auth.getSession().then(({ data }) => check(data.session));
    const { data: sub } = adminSb.auth.onAuthStateChange((_event, session) => {
      // On repousse l'appel pour ne pas bloquer le verrou interne de supabase-js
      setTimeout(() => check(session), 0);
    });
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const login = async (email, password) => {
    const { error } = await adminSb.auth.signInWithPassword({ email, password });
    if (error) throw error;
  };
  const logout = () => adminSb.auth.signOut();

  return <Ctx.Provider value={{ ...state, login, logout }}>{children}</Ctx.Provider>;
}

export const useAdminAuth = () => useContext(Ctx);
