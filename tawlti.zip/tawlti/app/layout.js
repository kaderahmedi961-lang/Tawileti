import "./globals.css";

export const metadata = {
  title: "Tawlti - طاولتي",
  description: "Plateforme pour restaurants · منصة للمطاعم",
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0F3924",
};

// Layout racine minimal : aucun composant partagé entre /admin et /dashboard.
export default function RootLayout({ children }) {
  return (
    <html lang="fr" dir="ltr">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
