"use client";

import { OwnerLangProvider, useOwnerLang } from "./_lib/i18n";
import { OwnerAuthProvider, useOwnerAuth } from "./_lib/auth";
import OwnerHeader from "./_components/OwnerHeader";

function Gate({ children }) {
  const { t } = useOwnerLang();
  const { ready, logout } = useOwnerAuth();

  if (!ready) {
    return (
      <div className="min-h-screen bg-sand flex items-center justify-center text-green-700 font-bold">
        {t("loading")}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-sand">
      <OwnerHeader onLogout={logout} />
      <main className="mx-auto max-w-3xl px-4 py-6">{children}</main>
    </div>
  );
}

// Layout /dashboard : fournisseurs, auth et en-tête propres aux restaurateurs
export default function DashboardLayout({ children }) {
  return (
    <OwnerLangProvider>
      <OwnerAuthProvider>
        <Gate>{children}</Gate>
      </OwnerAuthProvider>
    </OwnerLangProvider>
  );
}
