"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ownerSb } from "./supabase";

const Ctx = createContext(null);

// Auth restaurateur : il faut une ligne restaurant_owners avec status = "approved".
// Sinon : déconnexion immédiate et retour vers /login. Un admin n'a pas accès ici
// (pas de profil restaurant, et sa session est stockée sous une autre clé).
export function OwnerAuthProvider({ children }) {
  const router = useRouter();
  const [state, setState] = useState({ ready: false, user: null, profile: null });

  useEffect(() => {
    let alive = true;

    const check = async (session) => {
      if (!alive) return;
      const user = session?.user ?? null;
      if (!user) {
        setState({ ready: false, user: null, profile: null });
        return router.replace("/login");
      }
      const { data, error } = await ownerSb.from("restaurant_owners").select("*").eq("id", user.id).maybeSingle();
      if (!alive) return;
      if (error || !data || data.status !== "approved") {
        await ownerSb.auth.signOut();
        return router.replace("/login");
      }
      setState({ ready: true, user, profile: data });
    };

    ownerSb.auth.getSession().then(({ data }) => check(data.session));
    const { data: sub } = ownerSb.auth.onAuthStateChange((_event, session) => {
      setTimeout(() => check(session), 0);
    });
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
    };
  }, [router]);

  const logout = async () => {
    await ownerSb.auth.signOut();
    router.replace("/login");
  };

  return <Ctx.Provider value={{ ...state, logout }}>{children}</Ctx.Provider>;
}

export const useOwnerAuth = () => useContext(Ctx);
