import { createClient } from "@supabase/supabase-js";
import { SUPABASE_URL, SUPABASE_ANON_KEY } from "@/lib/supabaseConfig";

// Client restaurateur : même clé de session que /login (tawlti-owner-auth).
// Distinct de la session /admin (tawlti-admin-auth).
export const ownerSb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { storageKey: "tawlti-owner-auth" },
});
