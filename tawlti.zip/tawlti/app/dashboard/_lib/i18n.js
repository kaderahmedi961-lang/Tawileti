"use client";

import { createContext, useContext, useEffect, useState } from "react";

const dict = {
  fr: {
    loading: "Chargement…",
    logout: "Déconnexion",
    hello: "Bonjour",
    status_approved: "Compte approuvé",
    phone: "WhatsApp",
    email: "E-mail",
    empty_title: "Rien à afficher pour le moment",
    empty_text: "Votre espace restaurant est prêt. Vos tables et vos QR codes apparaîtront ici.",
    err_generic: "Une erreur est survenue. Réessayez.",
  },
  ar: {
    loading: "جارٍ التحميل…",
    logout: "تسجيل الخروج",
    hello: "مرحبًا",
    status_approved: "حساب مقبول",
    phone: "واتساب",
    email: "البريد الإلكتروني",
    empty_title: "لا شيء للعرض حاليًا",
    empty_text: "فضاء مطعمك جاهز. ستظهر هنا طاولاتك ورموز QR الخاصة بها.",
    err_generic: "حدث خطأ. حاول مرة أخرى.",
  },
};

const Ctx = createContext({ lang: "fr", setLang: () => {}, t: (k) => k });

export function OwnerLangProvider({ children }) {
  const [lang, setLangState] = useState("fr");

  useEffect(() => {
    try {
      const s = localStorage.getItem("tawlti_lang");
      if (s === "fr" || s === "ar") setLangState(s);
    } catch (e) {}
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);

  const setLang = (l) => {
    setLangState(l);
    try {
      localStorage.setItem("tawlti_lang", l);
    } catch (e) {}
  };

  const t = (k) => dict[lang][k] ?? dict.fr[k] ?? k;
  return <Ctx.Provider value={{ lang, setLang, t }}>{children}</Ctx.Provider>;
}

export const useOwnerLang = () => useContext(Ctx);
