"use client";

import { useOwnerAuth } from "./_lib/auth";
import { useOwnerLang } from "./_lib/i18n";

export default function DashboardPage() {
  const { t } = useOwnerLang();
  const { profile } = useOwnerAuth();

  return (
    <>
      <div className="bg-white rounded-3xl shadow-card overflow-hidden">
        {profile.restaurant_photo_url && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={profile.restaurant_photo_url} alt="" className="w-full h-44 object-cover" />
        )}
        <div className="p-5">
          <span className="inline-block rounded-full bg-green-50 text-green-700 text-xs font-extrabold px-3 py-1">
            ✓ {t("status_approved")}
          </span>
          <h1 className="text-2xl font-extrabold text-green-800 mt-3">{profile.restaurant_name}</h1>
          <p className="text-orange-600 font-bold">
            {t("hello")} {profile.name}
          </p>
          <div className="mt-3 space-y-1 text-sm text-green-800" dir="ltr">
            <div>
              📱 {t("phone")}: {profile.phone_whatsapp}
            </div>
            <div className="break-all">
              ✉️ {t("email")}: {profile.email}
            </div>
          </div>
        </div>
      </div>

      {/* État vide : aucune donnée n'existe encore (étape 2 : tables et QR) */}
      <div className="bg-white rounded-3xl shadow-card p-10 text-center mt-5">
        <div className="text-4xl mb-3">🪑</div>
        <h2 className="text-lg font-extrabold text-green-800">{t("empty_title")}</h2>
        <p className="text-sm text-green-700 mt-2">{t("empty_text")}</p>
      </div>
    </>
  );
}
