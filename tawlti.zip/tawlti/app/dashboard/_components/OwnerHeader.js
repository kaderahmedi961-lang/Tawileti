"use client";

import { useOwnerLang } from "../_lib/i18n";

export function OwnerLogo({ size = 40 }) {
  return (
    <div className="flex items-center gap-3">
      <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-label="Tawlti">
        <rect width="64" height="64" rx="16" fill="#0F3924" stroke="#ffffff33" />
        <rect x="21" y="9" width="22" height="22" rx="3" fill="#FFF9F0" />
        <rect x="24" y="12" width="6" height="6" rx="1" fill="#0F3924" />
        <rect x="34" y="12" width="6" height="6" rx="1" fill="#0F3924" />
        <rect x="24" y="22" width="6" height="6" rx="1" fill="#0F3924" />
        <rect x="34" y="22" width="3" height="3" fill="#E8741E" />
        <rect x="37" y="25" width="3" height="3" fill="#0F3924" />
        <rect x="10" y="35" width="44" height="7" rx="3.5" fill="#E8741E" />
        <rect x="16" y="42" width="5" height="14" rx="2" fill="#E8741E" />
        <rect x="43" y="42" width="5" height="14" rx="2" fill="#E8741E" />
      </svg>
      <div className="leading-tight">
        <div className="text-xl font-extrabold text-white">Tawlti</div>
        <div className="text-lg font-bold text-orange-400">طاولتي</div>
      </div>
    </div>
  );
}

export default function OwnerHeader({ onLogout }) {
  const { lang, setLang, t } = useOwnerLang();
  const base = "px-3 py-1 text-sm font-bold rounded-full transition";
  return (
    <header className="bg-green-800">
      <div className="mx-auto max-w-3xl flex items-center justify-between gap-3 px-4 py-3">
        <OwnerLogo />
        <div className="flex items-center gap-3">
          <div className="inline-flex p-1 rounded-full bg-white/15" dir="ltr">
            <button onClick={() => setLang("fr")} className={`${base} ${lang === "fr" ? "bg-white text-green-800" : "text-white"}`}>
              FR
            </button>
            <button onClick={() => setLang("ar")} className={`${base} ${lang === "ar" ? "bg-white text-green-800" : "text-white"}`}>
              عربي
            </button>
          </div>
          <button onClick={onLogout} className="text-sm font-bold text-white underline">
            {t("logout")}
          </button>
        </div>
      </div>
    </header>
  );
}
