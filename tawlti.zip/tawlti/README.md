# Tawlti - طاولتي

Plateforme pour restaurants (Next.js 14 + Tailwind CSS + **Supabase**). **Étape 1** : inscription, validation par l'admin, connexion.

## 1. Installation

```bash
npm install
cp .env.example .env.local   # puis remplir l'URL et la clé anon Supabase
npm run dev
```

## 2. Configuration Supabase

1. Créez un projet sur https://supabase.com
2. **SQL Editor** → collez et exécutez `supabase/schema.sql` (tables `admins` et `restaurant_owners`, RLS, bucket `restaurant-photos`, realtime).
3. **Authentication → Providers → Email** : désactivez **Confirm email** (l'approbation par l'admin remplace la confirmation).
4. **Project Settings → API** : copiez *Project URL* et *anon public key* dans `.env.local`.

## 3. Compte administrateur

1. **Authentication → Users → Add user** (e-mail + mot de passe fort, cochez *Auto Confirm User*).
2. Copiez son UUID et exécutez dans le SQL Editor :
   ```sql
   insert into public.admins (id, name, email) values ('<UUID>', '<Nom>', '<e-mail>');
   ```
3. Connectez-vous sur `/admin`.

## 4. Pages

| Route | Rôle |
|---|---|
| `/`, `/register`, `/login` | Pages publiques (`app/(public)`) |
| `/admin` | Espace admin : layout, auth, i18n et composants propres (`app/admin/_lib`, `_components`) |
| `/dashboard` | Espace restaurateur : layout, auth, i18n et composants propres (`app/dashboard/_lib`, `_components`) |

### Séparation admin / dashboard

- Aucun composant ni module partagé entre `/admin` et `/dashboard` (seule la config, simple donnée, est lue dans `lib/supabaseConfig.js`).
- `/admin` utilise un client Supabase avec sa propre clé de session (`tawlti-admin-auth`) : indépendante de celle des restaurateurs (`tawlti-owner-auth`). L'accès exige une ligne dans la table `admins`.
- `/dashboard` exige une ligne `restaurant_owners` avec `status = 'approved'`, sinon déconnexion et retour vers `/login`.
- Aucune donnée fictive : tout vient de Supabase, sinon un état vide s'affiche.

## 5. Tables

- `admins` : `id` (= auth.users.id), `name`, `email`, `created_at` — écriture manuelle uniquement.
- `restaurant_owners` : `id`, `name`, `restaurant_name`, `restaurant_photo_url`, `phone_whatsapp`, `email`, `status` (`pending` | `approved` | `rejected`), `created_at`, `reviewed_by`, `reviewed_at`.

## Notes

- Interface FR/AR avec bascule, RTL automatique en arabe.
- Les règles RLS empêchent un restaurant de se mettre lui-même en `approved` : seul un admin peut modifier le statut.
