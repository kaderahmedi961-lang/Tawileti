export default function Logo({ size = 56, withText = true, light = false }) {
  const textMain = light ? "#FFFFFF" : "#0F3924";
  return (
    <div className="flex items-center gap-3">
      <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-label="Tawlti">
        <rect width="64" height="64" rx="16" fill="#0F3924" />
        {/* QR code */}
        <rect x="21" y="9" width="22" height="22" rx="3" fill="#FFF9F0" />
        <rect x="24" y="12" width="6" height="6" rx="1" fill="#0F3924" />
        <rect x="34" y="12" width="6" height="6" rx="1" fill="#0F3924" />
        <rect x="24" y="22" width="6" height="6" rx="1" fill="#0F3924" />
        <rect x="34" y="22" width="3" height="3" fill="#E8741E" />
        <rect x="37" y="25" width="3" height="3" fill="#0F3924" />
        {/* Table */}
        <rect x="10" y="35" width="44" height="7" rx="3.5" fill="#E8741E" />
        <rect x="16" y="42" width="5" height="14" rx="2" fill="#E8741E" />
        <rect x="43" y="42" width="5" height="14" rx="2" fill="#E8741E" />
      </svg>
      {withText && (
        <div className="leading-tight">
          <div className="text-xl font-extrabold" style={{ color: textMain }}>
            Tawlti
          </div>
          <div className="text-lg font-bold text-orange-500">طاولتي</div>
        </div>
      )}
    </div>
  );
}
