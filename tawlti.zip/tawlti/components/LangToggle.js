"use client";

import { useLang } from "@/lib/i18n";

export default function LangToggle({ light = false }) {
  const { lang, setLang } = useLang();
  const base = "px-3 py-1 text-sm font-bold rounded-full transition";
  const wrap = light ? "bg-white/15" : "bg-green-50 border border-green-100";
  const on = light ? "bg-white text-green-800" : "bg-green-800 text-white";
  const off = light ? "text-white" : "text-green-800";
  return (
    <div className={`inline-flex p-1 rounded-full ${wrap}`} dir="ltr">
      <button onClick={() => setLang("fr")} className={`${base} ${lang === "fr" ? on : off}`}>
        FR
      </button>
      <button onClick={() => setLang("ar")} className={`${base} ${lang === "ar" ? on : off}`}>
        عربي
      </button>
    </div>
  );
}
