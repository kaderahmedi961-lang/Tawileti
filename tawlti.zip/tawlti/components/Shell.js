"use client";

import Link from "next/link";
import Logo from "@/components/Logo";
import LangToggle from "@/components/LangToggle";

// Cadre commun des pages (mobile first)
export default function Shell({ children, wide = false }) {
  return (
    <div className="min-h-screen bg-sand">
      <header className="bg-green-800">
        <div className={`mx-auto flex items-center justify-between px-4 py-3 ${wide ? "max-w-4xl" : "max-w-md"}`}>
          <Link href="/">
            <Logo size={40} light />
          </Link>
          <LangToggle light />
        </div>
      </header>
      <main className={`mx-auto px-4 py-6 ${wide ? "max-w-4xl" : "max-w-md"}`}>{children}</main>
    </div>
  );
}

export function Field({ label, hint, children }) {
  return (
    <label className="block">
      <span className="block text-sm font-bold text-green-800 mb-1">{label}</span>
      {children}
      {hint && <span className="block text-xs text-green-700/70 mt-1">{hint}</span>}
    </label>
  );
}

export const inputClass =
  "w-full rounded-xl border border-green-100 bg-white px-4 py-3 text-base text-green-900 placeholder-green-700/40 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-orange-400";

export const primaryBtn =
  "w-full rounded-xl bg-orange-500 hover:bg-orange-600 active:scale-[0.99] disabled:opacity-60 text-white font-extrabold py-3.5 text-base shadow-card transition";
